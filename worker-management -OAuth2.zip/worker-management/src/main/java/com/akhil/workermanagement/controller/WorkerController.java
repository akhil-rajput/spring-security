package com.akhil.workermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.akhil.workermanagement.model.Worker;
import com.akhil.workermanagement.service.WorkerService;

@RestController
public class WorkerController {

	@Autowired
	private WorkerService workerService;

	RestTemplate restTemplate = new RestTemplate();

	@GetMapping("/assignedworker")
	public String getNextWorker() {
		Worker assignedWorker = workerService.findAssignedWorker();
		if (assignedWorker != null) {
			return "Assigned worker is: " + assignedWorker.getName();
		} else {
			return "No worker found.";
		}

	}

	@GetMapping("/")
	public String main(OAuth2AuthenticationToken token) {
		String url = token.getPrincipal().getAttribute("repos_url");
       ResponseEntity<String> response= restTemplate.getForEntity(url, String.class);
       String accessToken = response.getBody();	
       return accessToken;
	}
}
