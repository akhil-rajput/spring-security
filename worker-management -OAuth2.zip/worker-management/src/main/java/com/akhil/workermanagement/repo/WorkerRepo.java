package com.akhil.workermanagement.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akhil.workermanagement.model.Worker;

public interface WorkerRepo extends JpaRepository<Worker, Long> {
	Worker findByHasAssignedWorkIsTrue();

	Worker findTop1ByHasAssignedWorkIsFalseAndIdGreaterThanOrderByIdAsc(Long id);

	Worker findTop1ByHasAssignedWorkIsFalseOrderByIdAsc();
}
