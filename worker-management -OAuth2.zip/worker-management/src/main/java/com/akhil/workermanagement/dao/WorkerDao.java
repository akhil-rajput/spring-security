package com.akhil.workermanagement.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.akhil.workermanagement.model.Worker;
import com.akhil.workermanagement.repo.WorkerRepo;
import com.zaxxer.hikari.HikariDataSource;

@Component
public class WorkerDao {

	@Autowired
	WorkerRepo workerRepo;

	public Worker findNextWorkerWithAssignedTask() {
		Worker userWithTask = workerRepo.findByHasAssignedWorkIsTrue();
		

		if (userWithTask != null) {
			Worker nextUser = workerRepo
					.findTop1ByHasAssignedWorkIsFalseAndIdGreaterThanOrderByIdAsc(userWithTask.getId());

			if (nextUser == null) {
				nextUser = workerRepo.findTop1ByHasAssignedWorkIsFalseOrderByIdAsc();
			}

			if (nextUser != null) {
				userWithTask.setHasAssignedWork(false);
				nextUser.setHasAssignedWork(true);

				workerRepo.saveAll(List.of(userWithTask, nextUser));

				return nextUser;
			}
		}
		return null;
	}

	public Worker findWorkerWithAssignedTask() {
		// Find the user with hasAssignedTask set to true
		Worker userWithTask = workerRepo.findByHasAssignedWorkIsTrue();
		return userWithTask;
	}
}
