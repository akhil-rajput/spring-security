package com.akhil.workermanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import com.akhil.workermanagement.dao.WorkerDao;
import com.akhil.workermanagement.model.Worker;

@Service
public class WorkerService {

	@Autowired
	WorkerDao workerDao;

	@Scheduled(cron = "0/15 * * * * *")
	public Worker findNextWorker() {
		Worker nextWorker = workerDao.findNextWorkerWithAssignedTask();
		return nextWorker != null ? nextWorker : null;
	}
	
	public Worker findAssignedWorker() {
		return workerDao.findWorkerWithAssignedTask();
	}

}
