package com.akhil.workermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.filter.DelegatingFilterProxy;

import com.akhil.workermanagement.model.Worker;
import com.akhil.workermanagement.service.WorkerService;

@RestController
public class WorkerController {

	@Autowired
	private WorkerService workerService;

	@GetMapping("/assignedworker")
	public String getNextWorker() {

		long st = System.currentTimeMillis();
		System.out.println("");
		Worker assignedWorker = workerService.findAssignedWorker();
		if (assignedWorker != null) {
			long end = System.currentTimeMillis();
			System.out.println(
					"total Time taken by " + Thread.currentThread().getName() + " to complete req " + (end - st));
			return "Assigned worker is: " + assignedWorker.getName();
		} else {
			return "No worker found.";
		}
		
	}
}
