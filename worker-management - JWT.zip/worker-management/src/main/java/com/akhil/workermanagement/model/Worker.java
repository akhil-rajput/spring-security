package com.akhil.workermanagement.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "workers")
public class Worker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "worker_id", nullable = false, unique = true)
    private String workerId;

    @Column(name = "has_assigned_work")
    private boolean hasAssignedWork;

    // Constructors, getters, and setters

    public Worker() {
        // Default constructor
    }

    public Worker(String name, String workerId, boolean hasAssignedWork) {
        this.name = name;
        this.workerId = workerId;
        this.hasAssignedWork = hasAssignedWork;
    }

    // Getter and setter methods for id, name, workerId, and hasAssignedWork

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkerId() {
        return workerId;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public boolean isHasAssignedWork() {
        return hasAssignedWork;
    }

    public void setHasAssignedWork(boolean hasAssignedWork) {
        this.hasAssignedWork = hasAssignedWork;
    }

	@Override
	public String toString() {
		return "Worker [id=" + id + ", name=" + name + ", workerId=" + workerId + ", hasAssignedWork=" + hasAssignedWork
				+ "]";
	}
    
}
