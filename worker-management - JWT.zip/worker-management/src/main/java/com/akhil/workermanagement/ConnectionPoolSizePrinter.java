package com.akhil.workermanagement;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ConnectionPoolSizePrinter implements CommandLineRunner {

    @Autowired
    private HikariDataSource dataSource;
    
    @Value("${jwt.header}")
	private String tokenHeader;

    @Override
    public void run(String... args) throws Exception {
        int maxPoolSize = dataSource.getMaximumPoolSize();
        int minIdle = dataSource.getMinimumIdle();
        System.out.println("Max Pool Size: " + maxPoolSize);
        System.out.println("Min Idle Connections: " + minIdle);
        System.out.println("sk "+tokenHeader);
    }
}
