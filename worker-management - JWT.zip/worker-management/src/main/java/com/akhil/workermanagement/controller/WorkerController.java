package com.akhil.workermanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.akhil.workermanagement.model.User;
import com.akhil.workermanagement.model.Worker;
import com.akhil.workermanagement.service.UserDetailsServiceImpl;
import com.akhil.workermanagement.service.WorkerService;

@RestController
public class WorkerController {

	@Autowired
	private WorkerService workerService;
	
	@Autowired
	UserDetailsServiceImpl userDetailsService;

	@GetMapping("/assignedworker")
	@PreAuthorize("hasRole('USER')")
	public String getNextWorker() {

		long st = System.currentTimeMillis();
		System.out.println("");
		Worker assignedWorker = workerService.findAssignedWorker();
		if (assignedWorker != null) {
			return "Assigned worker is: " + assignedWorker.getName();
		} else {
			return "No worker found.";
		}

	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody User user) throws Exception {
		userDetailsService.saveUser(user.getUsername(),user.getPassword(),user.getRoles());
		return ResponseEntity.ok(200);
	}
}
